#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Tue Mar 28 12:08:57 2023

@author: chadpenny
"""
import requests
import json
import pandas as pd


# Define the endpoint URL and API key
url = "https://api.rescuegroups.org/http/v2.json"
api_key = "L7LDTwxI"

params = {
    "apikey": api_key,
    "objectType": "animals",
    "objectAction": "publicSearch",
    "search": {
        "resultStart": 0,
        "resultLimit":5000,
        "resultSort": "animalID",
        "fields": ['animalID', 'animalOrgID', 'animalActivityLevel', 'animalAdoptionFee', 
                     'animalAltered', 'animalAvailableDate', 'animalBirthdate', 'animalBirthdateExact', 
                     'animalBreed', 'animalCoatLength', 'animalColor', 'animalColorID', 'animalColorDetails', 
                     'animalCourtesy', 'animalDeclawed', 'animalDescription', 'animalDescriptionPlain', 
                     'animalDistinguishingMarks', 'animalEarType', 'animalEnergyLevel', 'animalExerciseNeeds', 
                     'animalEyeColor', 'animalFence', 'animalFound', 'animalFoundDate', 'animalFoundPostalcode', 
                     'animalGeneralAge', 'animalGeneralSizePotential', 'animalGroomingNeeds', 'animalHousetrained', 
                     'animalIndoorOutdoor', 'animalKillDate', 'animalKillReason', 'animalLocation', 
                     'animalLocationDistance', 'animalLocationCitystate', 'animalMicrochipped', 'animalMixedBreed', 
                     'animalName', 'animalSpecialneeds', 'animalSpecialneedsDescription', 'animalNeedsFoster', 
                     'animalNewPeople', 'animalNotHousetrainedReason', 'animalObedienceTraining', 'animalOKWithAdults', 
                     'animalOKWithCats', 'animalOKWithDogs', 'animalOKWithKids', 'animalOwnerExperience', 'animalPattern', 
                     'animalPatternID', 'animalAdoptionPending', 'animalPrimaryBreed', 'animalPrimaryBreedID', 
                     'animalRescueID', 'animalSearchString', 'animalSecondaryBreed', 'animalSecondaryBreedID', 
                     'animalSex', 'animalShedding', 'animalSizeCurrent', 'animalSizePotential', 'animalSizeUOM', 
                     'animalSpecies', 'animalSpeciesID', 'animalSponsorable', 'animalSponsors', 'animalSponsorshipDetails', 
                     'animalSponsorshipMinimum', 'animalStatus', 'animalStatusID', 'animalSummary', 'animalTailType', 
                     'animalThumbnailUrl', 'animalUptodate', 'animalUpdatedDate', 'animalUrl', 'animalVocal', 
                     'animalYardRequired', 'animalAffectionate', 'animalApartment', 'animalCratetrained', 
                     'animalDrools', 'animalEagerToPlease', 'animalEscapes', 'animalEventempered', 'animalFetches', 
                     'animalGentle', 'animalGoodInCar', 'animalGoofy', 'animalHasAllergies', 'animalHearingImpaired', 
                     'animalHypoallergenic', 'animalIndependent', 'animalIntelligent', 'animalLap', 'animalLeashtrained',  
                     'animalNoCold', 'animalNoFemaleDogs', 'animalNoHeat', 'animalNoLargeDogs', 'animalNoMaleDogs', 
                     'animalNoSmallDogs', 'animalObedient', 'animalOKForSeniors', 'animalOKWithFarmAnimals', 
                     'animalOlderKidsOnly', 'animalOngoingMedical', 'animalPlayful', 'animalPlaysToys', 
                      'animalProtective', 'animalSightImpaired', 'animalSkittish', 
                     'animalSpecialDiet','animalSwims', 'animalTimid', 'fosterEmail', 'fosterFirstname', 
                     'fosterLastname', 'fosterName', 'fosterPhoneCell', 'fosterPhoneHome', 'fosterSalutation', 
                     'locationAddress', 'locationCity', 'locationCountry', 'locationUrl', 'locationName', 'locationPhone', 
                     'locationState', 'locationPostalcode', 'animalPictures', 'animalVideos', 'animalVideoUrls'],

        "filters": [
            {
                "fieldName": "animalSpecies",
                "operation": "equals",
                "criteria": "Dog"
            },
            {
                "fieldName": "animalStatus",
                "operation": "equals",
                "criteria": "Available" ##Change to Adopted to see adopted 
            }

        ]
    }
}


df= pd.DataFrame()
data_list = []
for i in range(0, 50000, 5000):
    params["search"]["resultStart"] = i
    response = requests.post(url, json=params)
    if response.status_code == 200:
        data = json.loads(response.text)
        df = df.append(pd.DataFrame(data["data"]),ignore_index=True)
        print("Fetched data for range", i, "-", i+5000)
    else:
        print("Unable to connect for range", i, "-", i+5000)

# Convert the list of dictionaries to a Pandas DataFrame

df=df.transpose()
df = df.drop(columns=df.columns[135:])
df.columns=['animalID', 'animalOrgID', 'animalActivityLevel', 'animalAdoptionFee', 
             'animalAltered', 'animalAvailableDate', 'animalBirthdate', 'animalBirthdateExact', 
             'animalBreed', 'animalCoatLength', 'animalColor', 'animalColorID', 'animalColorDetails', 
             'animalCourtesy', 'animalDeclawed', 'animalDescription', 'animalDescriptionPlain', 
             'animalDistinguishingMarks', 'animalEarType', 'animalEnergyLevel', 'animalExerciseNeeds', 
             'animalEyeColor', 'animalFence', 'animalFound', 'animalFoundDate', 'animalFoundPostalcode', 
             'animalGeneralAge', 'animalGeneralSizePotential', 'animalGroomingNeeds', 'animalHousetrained', 
             'animalIndoorOutdoor', 'animalKillDate', 'animalKillReason', 'animalLocation', 
             'animalLocationDistance', 'animalLocationCitystate', 'animalMicrochipped', 'animalMixedBreed', 
             'animalName', 'animalSpecialneeds', 'animalSpecialneedsDescription', 'animalNeedsFoster', 
             'animalNewPeople', 'animalNotHousetrainedReason', 'animalObedienceTraining', 'animalOKWithAdults', 
             'animalOKWithCats', 'animalOKWithDogs', 'animalOKWithKids', 'animalOwnerExperience', 'animalPattern', 
             'animalPatternID', 'animalAdoptionPending', 'animalPrimaryBreed', 'animalPrimaryBreedID', 
             'animalRescueID', 'animalSearchString', 'animalSecondaryBreed', 'animalSecondaryBreedID', 
             'animalSex', 'animalShedding', 'animalSizeCurrent', 'animalSizePotential', 'animalSizeUOM', 
             'animalSpecies', 'animalSpeciesID', 'animalSponsorable', 'animalSponsors', 'animalSponsorshipDetails', 
             'animalSponsorshipMinimum', 'animalStatus', 'animalStatusID', 'animalSummary', 'animalTailType', 
             'animalThumbnailUrl', 'animalUptodate', 'animalUpdatedDate', 'animalUrl', 'animalVocal', 
             'animalYardRequired', 'animalAffectionate', 'animalApartment', 'animalCratetrained', 
             'animalDrools', 'animalEagerToPlease', 'animalEscapes', 'animalEventempered', 'animalFetches', 
             'animalGentle', 'animalGoodInCar', 'animalGoofy', 'animalHasAllergies', 'animalHearingImpaired', 
             'animalHypoallergenic', 'animalIndependent', 'animalIntelligent', 'animalLap', 'animalLeashtrained',  
             'animalNoCold', 'animalNoFemaleDogs', 'animalNoHeat', 'animalNoLargeDogs', 'animalNoMaleDogs', 
             'animalNoSmallDogs', 'animalObedient', 'animalOKForSeniors', 'animalOKWithFarmAnimals', 
             'animalOlderKidsOnly', 'animalOngoingMedical', 'animalPlayful', 'animalPlaysToys', 
             'animalProtective', 'animalSightImpaired', 'animalSkittish', 
             'animalSpecialDiet','animalSwims', 'animalTimid', 'fosterEmail', 'fosterFirstname', 
             'fosterLastname', 'fosterName', 'fosterPhoneCell', 'fosterPhoneHome', 'fosterSalutation', 
             'locationAddress', 'locationCity', 'locationCountry', 'locationUrl', 'locationName', 'locationPhone', 
             'locationState', 'locationPostalcode', 'animalPictures', 'animalVideos', 'animalVideoUrls']
df2 = df[['animalID', 'animalOrgID', 'animalActivityLevel', 'animalAdoptionFee', 
             'animalAltered', 'animalAvailableDate', 'animalBirthdate', 'animalBirthdateExact', 
             'animalBreed', 'animalCoatLength', 'animalColor', 'animalColorID', 'animalColorDetails', 
             'animalCourtesy', 'animalDeclawed', 'animalDescription', 'animalDescriptionPlain', 
             'animalDistinguishingMarks', 'animalEarType', 'animalEnergyLevel', 'animalExerciseNeeds', 
             'animalEyeColor', 'animalFence', 'animalFound', 'animalFoundDate', 'animalFoundPostalcode', 
             'animalGeneralAge', 'animalGeneralSizePotential', 'animalGroomingNeeds', 'animalHousetrained', 
             'animalIndoorOutdoor', 'animalKillDate', 'animalKillReason', 'animalLocation', 
             'animalLocationDistance', 'animalLocationCitystate', 'animalMicrochipped', 'animalMixedBreed', 
             'animalName', 'animalSpecialneeds', 'animalSpecialneedsDescription', 'animalNeedsFoster', 
             'animalNewPeople', 'animalNotHousetrainedReason', 'animalObedienceTraining', 'animalOKWithAdults', 
             'animalOKWithCats', 'animalOKWithDogs', 'animalOKWithKids', 'animalOwnerExperience', 'animalPattern', 
             'animalPatternID', 'animalAdoptionPending', 'animalPrimaryBreed', 'animalPrimaryBreedID', 
             'animalRescueID', 'animalSearchString', 'animalSecondaryBreed', 'animalSecondaryBreedID', 
             'animalSex', 'animalShedding', 'animalSizeCurrent', 'animalSizePotential', 'animalSizeUOM', 
             'animalSpecies', 'animalSpeciesID', 'animalSponsorable', 'animalSponsors', 'animalSponsorshipDetails', 
             'animalSponsorshipMinimum', 'animalStatus', 'animalStatusID', 'animalSummary', 'animalTailType', 
             'animalThumbnailUrl', 'animalUptodate', 'animalUpdatedDate', 'animalUrl', 'animalVocal', 
             'animalYardRequired', 'animalAffectionate', 'animalApartment', 'animalCratetrained', 
             'animalDrools', 'animalEagerToPlease', 'animalEscapes', 'animalEventempered', 'animalFetches', 
             'animalGentle', 'animalGoodInCar', 'animalGoofy', 'animalHasAllergies', 'animalHearingImpaired', 
             'animalHypoallergenic', 'animalIndependent', 'animalIntelligent', 'animalLap', 'animalLeashtrained',  
             'animalNoCold', 'animalNoFemaleDogs', 'animalNoHeat', 'animalNoLargeDogs', 'animalNoMaleDogs', 
             'animalNoSmallDogs', 'animalObedient', 'animalOKForSeniors', 'animalOKWithFarmAnimals', 
             'animalOlderKidsOnly', 'animalOngoingMedical', 'animalPlayful', 'animalPlaysToys', 
             'animalProtective', 'animalSightImpaired', 'animalSkittish', 
             'animalSpecialDiet','animalSwims', 'animalTimid', 'fosterEmail', 'fosterFirstname', 
             'fosterLastname', 'fosterName', 'fosterPhoneCell', 'fosterPhoneHome', 'fosterSalutation', 
             'locationAddress', 'locationCity', 'locationCountry', 'locationUrl', 'locationName', 'locationPhone', 
             'locationState', 'locationPostalcode', 'animalPictures', 'animalVideos', 'animalVideoUrls']]
df2=df2.reset_index()
df2.to_csv('Available_Final.csv', index=True)
df.replace('', None, inplace=True)

