#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Wed Apr 19 20:27:21 2023

@author: chadpenny
"""

import pandas as pd

# Define a list of CSV file names
csv_files = ['Adopted_Final.csv','Available_Final.csv', 'Euthanized_Final.csv', 'Pending_Final.csv', 'Transferred_Final.csv', 'Foster_Final.csv']

dfs = []

for file in csv_files:
    df = pd.read_csv(file)
    dfs.append(df)
    print('done1')



final_df = pd.concat(dfs, ignore_index=True)
final_df = final_df.drop(final_df.columns[1],axis=1)
final_df.to_csv('Data_master.csv', index=True)

df_adopt = pd.read_csv('Adopted_Final.csv')
df_avail = pd.read_csv('Available_Final.csv')
df_euth = pd.read_csv('Euthanized_Final.csv')
df_pending = pd.read_csv('Pending_Final.csv')
df_trans = pd.read_csv('Transferred_Final.csv')
df_fost = pd.read_csv('Foster_Final.csv')


