#!/usr/bin/env python3
# -*- coding: utf-8 -*-
#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Tue Mar 28 12:08:57 2023

@author: chadpenny
"""
import requests
import json
import pandas as pd



url = "https://api.rescuegroups.org/http/v2.json"
api_key = "L7LDTwxI"

params = {
    "apikey": api_key,
    "objectType": "animals",
    "objectAction": "publicSearch",
    "search": {
        "resultStart": 0,
        "resultLimit":40000,
        "resultSort": "animalID",
        "fields": ['animalID', 'animalOrgID', 'animalActivityLevel', 'animalAdoptionFee', 
                     'animalAltered', 'animalAvailableDate', 'animalBirthdate', 'animalBirthdateExact', 
                     'animalBreed', 'animalCoatLength', 'animalColor', 'animalColorID', 'animalColorDetails', 
                     'animalCourtesy', 'animalDeclawed', 'animalDescription', 'animalDescriptionPlain', 
                     'animalDistinguishingMarks', 'animalEarType', 'animalEnergyLevel', 'animalExerciseNeeds', 
                     'animalEyeColor', 'animalFence', 'animalFound', 'animalFoundDate', 'animalFoundPostalcode', 
                     'animalGeneralAge', 'animalGeneralSizePotential', 'animalGroomingNeeds', 'animalHousetrained', 
                     'animalIndoorOutdoor', 'animalKillDate', 'animalKillReason', 'animalLocation', 
                     'animalLocationDistance', 'animalLocationCitystate', 'animalMicrochipped', 'animalMixedBreed', 
                     'animalName', 'animalSpecialneeds', 'animalSpecialneedsDescription', 'animalNeedsFoster', 
                     'animalNewPeople', 'animalNotHousetrainedReason', 'animalObedienceTraining', 'animalOKWithAdults', 
                     'animalOKWithCats', 'animalOKWithDogs', 'animalOKWithKids', 'animalOwnerExperience', 'animalPattern', 
                     'animalPatternID', 'animalAdoptionPending', 'animalPrimaryBreed', 'animalPrimaryBreedID', 
                     'animalRescueID', 'animalSearchString', 'animalSecondaryBreed', 'animalSecondaryBreedID', 
                     'animalSex', 'animalShedding', 'animalSizeCurrent', 'animalSizePotential', 'animalSizeUOM', 
                     'animalSpecies', 'animalSpeciesID', 'animalSponsorable', 'animalSponsors', 'animalSponsorshipDetails', 
                     'animalSponsorshipMinimum', 'animalStatus', 'animalStatusID', 'animalSummary', 'animalTailType', 
                     'animalThumbnailUrl', 'animalUptodate', 'animalUpdatedDate', 'animalUrl', 'animalVocal', 
                     'animalYardRequired', 'animalAffectionate', 'animalApartment', 'animalCratetrained', 
                     'animalDrools', 'animalEagerToPlease', 'animalEscapes', 'animalEventempered', 'animalFetches', 
                     'animalGentle', 'animalGoodInCar', 'animalGoofy', 'animalHasAllergies', 'animalHearingImpaired', 
                     'animalHypoallergenic', 'animalIndependent', 'animalIntelligent', 'animalLap', 'animalLeashtrained',  
                     'animalNoCold', 'animalNoFemaleDogs', 'animalNoHeat', 'animalNoLargeDogs', 'animalNoMaleDogs', 
                     'animalNoSmallDogs', 'animalObedient', 'animalOKForSeniors', 'animalOKWithFarmAnimals', 
                     'animalOlderKidsOnly', 'animalOngoingMedical', 'animalPlayful', 'animalPlaysToys', 
                      'animalProtective', 'animalSightImpaired', 'animalSkittish', 
                     'animalSpecialDiet','animalSwims', 'animalTimid', 'fosterEmail', 'fosterFirstname', 
                     'fosterLastname', 'fosterName', 'fosterPhoneCell', 'fosterPhoneHome', 'fosterSalutation', 
                     'locationAddress', 'locationCity', 'locationCountry', 'locationUrl', 'locationName', 'locationPhone', 
                     'locationState', 'locationPostalcode', 'animalPictures', 'animalVideos', 'animalVideoUrls'],

        "filters": [
            {
                "fieldName": "animalSpecies",
                "operation": "equals",
                "criteria": "Dog"
            },
            {
                "fieldName": "animalStatus",
                "operation": "equals",
                "criteria": "Transferred" ##Change to Adopted to see adopted 
            }

        ]
    }
}


response = requests.post(url, json=params)


if response.status_code == 200:
    data = json.loads(response.text)
    print("Good connection")
else:
    print("Unable to connect", response.status_code)

df = pd.DataFrame.from_dict(data['data'], orient='index')


df2 = df[['animalID', 'animalOrgID', 'animalActivityLevel', 'animalAdoptionFee', 
             'animalAltered', 'animalAvailableDate', 'animalBirthdate', 'animalBirthdateExact', 
             'animalBreed', 'animalCoatLength', 'animalColor', 'animalColorID', 'animalColorDetails', 
             'animalCourtesy', 'animalDeclawed', 'animalDescription', 'animalDescriptionPlain', 
             'animalDistinguishingMarks', 'animalEarType', 'animalEnergyLevel', 'animalExerciseNeeds', 
             'animalEyeColor', 'animalFence', 'animalFound', 'animalFoundDate', 'animalFoundPostalcode', 
             'animalGeneralAge', 'animalGeneralSizePotential', 'animalGroomingNeeds', 'animalHousetrained', 
             'animalIndoorOutdoor', 'animalKillDate', 'animalKillReason', 'animalLocation', 
             'animalLocationDistance', 'animalLocationCitystate', 'animalMicrochipped', 'animalMixedBreed', 
             'animalName', 'animalSpecialneeds', 'animalSpecialneedsDescription', 'animalNeedsFoster', 
             'animalNewPeople', 'animalNotHousetrainedReason', 'animalObedienceTraining', 'animalOKWithAdults', 
             'animalOKWithCats', 'animalOKWithDogs', 'animalOKWithKids', 'animalOwnerExperience', 'animalPattern', 
             'animalPatternID', 'animalAdoptionPending', 'animalPrimaryBreed', 'animalPrimaryBreedID', 
             'animalRescueID', 'animalSearchString', 'animalSecondaryBreed', 'animalSecondaryBreedID', 
             'animalSex', 'animalShedding', 'animalSizeCurrent', 'animalSizePotential', 'animalSizeUOM', 
             'animalSpecies', 'animalSpeciesID', 'animalSponsorable', 'animalSponsors', 'animalSponsorshipDetails', 
             'animalSponsorshipMinimum', 'animalStatus', 'animalStatusID', 'animalSummary', 'animalTailType', 
             'animalThumbnailUrl', 'animalUptodate', 'animalUpdatedDate', 'animalUrl', 'animalVocal', 
             'animalYardRequired', 'animalAffectionate', 'animalApartment', 'animalCratetrained', 
             'animalDrools', 'animalEagerToPlease', 'animalEscapes', 'animalEventempered', 'animalFetches', 
             'animalGentle', 'animalGoodInCar', 'animalGoofy', 'animalHasAllergies', 'animalHearingImpaired', 
             'animalHypoallergenic', 'animalIndependent', 'animalIntelligent', 'animalLap', 'animalLeashtrained',  
             'animalNoCold', 'animalNoFemaleDogs', 'animalNoHeat', 'animalNoLargeDogs', 'animalNoMaleDogs', 
             'animalNoSmallDogs', 'animalObedient', 'animalOKForSeniors', 'animalOKWithFarmAnimals', 
             'animalOlderKidsOnly', 'animalOngoingMedical', 'animalPlayful', 'animalPlaysToys', 
             'animalProtective', 'animalSightImpaired', 'animalSkittish', 
             'animalSpecialDiet','animalSwims', 'animalTimid', 'fosterEmail', 'fosterFirstname', 
             'fosterLastname', 'fosterName', 'fosterPhoneCell', 'fosterPhoneHome', 'fosterSalutation', 
             'locationAddress', 'locationCity', 'locationCountry', 'locationUrl', 'locationName', 'locationPhone', 
             'locationState', 'locationPostalcode', 'animalPictures', 'animalVideos', 'animalVideoUrls']]
df2=df2.reset_index()
df2.to_csv('Transferred_Final.csv', index=True)
df.replace('', None, inplace=True)



